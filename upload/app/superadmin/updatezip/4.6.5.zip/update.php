<?php
//数据库变更
mysql_query("ALTER TABLE `{$_G['MYSQL']['PREFIX']}user` ADD `regip` VARCHAR(255) NULL, ADD `loginip` VARCHAR(255) NULL");
file_put_contents($_G['SYSTEM']['PATH'] . 'update.php', '<?php ?>');
